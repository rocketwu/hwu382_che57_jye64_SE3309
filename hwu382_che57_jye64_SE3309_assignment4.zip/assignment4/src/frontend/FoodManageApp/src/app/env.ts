import {HttpHeaders} from '@angular/common/http';

export class Env {
  public static serverURL = 'http://localhost:9000';
}
